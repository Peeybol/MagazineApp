﻿using System.Collections.Generic;
using System.Linq;

namespace Magazine.Entities
{
    public partial class $safeitemname$
    {
    }
}
